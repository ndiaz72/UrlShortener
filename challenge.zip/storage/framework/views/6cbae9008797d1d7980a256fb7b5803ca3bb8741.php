
<?php $__env->startSection('title', 'Url | Redirecting...'); ?>

<?php $__env->startSection('content'); ?>

<div class="container mt-5">
    <div class="row">
        <div class="col-6 mx-auto text-center">
            <h3>Redirigiendo en <span id="countdown">5</span> .. </h3>

        </div>
    </div>

</div>

<script>
    $(document).ready(function() {
        var seconds = 4;
        var countdownElement = $('#countdown');

        var interval = setInterval(function() {
            countdownElement.text(seconds);
            seconds--;

            if (seconds <= 0) {
                window.location.href = '<?php echo e($original); ?>';
            }
        }, 1000);
    });
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\challenge\resources\views\countdown.blade.php ENDPATH**/ ?>