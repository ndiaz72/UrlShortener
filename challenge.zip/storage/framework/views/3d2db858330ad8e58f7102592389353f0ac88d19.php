<!-- Alert for success or error messages -->
<div id="message" style=" position: fixed;bottom: 0;left: 0;width: 100%;" class="animate__delay-2s animate__animated animate__fadeOutDown	">
    <?php if(session('success')): ?>
    <div class="alert alert-success rounded-0">
        <?php echo e(session('success')); ?>

    </div>
    <?php endif; ?>
    <?php if($errors->any()): ?>
    <div class="alert alert-danger pb-0 rounded-0">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
    <?php endif; ?>
</div>


<script src="<?php echo e(asset('js/scripts.js')); ?>"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js"></script><?php /**PATH C:\xampp\htdocs\challenge\resources\views\layouts\footer.blade.php ENDPATH**/ ?>