
<?php $__env->startSection('title', 'Url | Home'); ?>
<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->startSection('content'); ?>

<div class="container mt-5">
    <!-- Table -->
    <div class="row">
        <div class="col-md-10 mx-auto">

            <table class="table table-hover cell-border hover dt-body-center stripe" id="datatable">
                <thead class="table-dark mt-">
                    <tr>
                        <th scope="col">ID</th>
                        <th scope="col">Code</th>
                        <th scope="col">Originar Url</th>
                        <th scope="col">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if($urls->isEmpty()): ?>
                    <tr>
                        <td scope="col">ID</td>
                        <td scope="col">Code</td>
                        <td scope="col">Original Url</td>
                        <td scope="col">Action</td>

                    </tr>

                    <?php endif; ?>

                    <?php $__currentLoopData = $urls; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($url->id); ?></td>
                        <td><?php echo e($url->shortened_url); ?></td>
                        <td><?php echo e($url->original_url); ?></td>
                        <td>
                            <form action="<?php echo e(route('urls.destroy', $url->id)); ?>" method="POST" style="display:inline;" id="deleteUrl">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-outline-danger btn-sm">Delete</button>
                            </form>

                            <a href="<?php echo e(url( $url->shortened_url )); ?>" class="btn btn-secondary btn-sm">Go</a>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\challenge\resources\views\home.blade.php ENDPATH**/ ?>