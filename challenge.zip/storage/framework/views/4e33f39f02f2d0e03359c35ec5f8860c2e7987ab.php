
<?php $__env->startSection('title', 'Url | Create'); ?>
<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
<?php $__env->startSection('content'); ?>

<div class="container mt-5">
    <!-- Table -->
    <div class="row">

        <div class="col-md-6 mx-auto">
            <h3>Create a New URL</h3>

            <div class="card">
                <div class="card-body">
                    <form action="<?php echo e(route('url.store')); ?>" method="POST">
                        <?php echo csrf_field(); ?>

                        <div class="mb-3">
                            <label for="original_url" class="form-label">Original URL</label>
                            <input type="url" class="form-control" id="original_url" name="original_url" placeholder="Enter the original URL" required>
                        </div>
                        <button type="submit" class="btn btn-primary w-100">Create URL</button>
                    </form>
                        <a href="<?php echo e(url('/')); ?>" class="btn btn-outline-secondary w-100"> Return to Home</a>
                </div>
            </div>
        </div>
    </div>





</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\challenge\resources\views\create.blade.php ENDPATH**/ ?>